# ruff: noqa

from .core import *
from .channels import *

SCHEMA_VERSION = "v5.20.1"

SCHEMA_URL = "https://vega.github.io/schema/vega-lite/v5.20.1.json"
