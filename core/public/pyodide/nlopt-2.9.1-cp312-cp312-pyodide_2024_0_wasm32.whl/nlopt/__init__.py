from .nlopt import *

__version__ = '2.9.1'
