#!/usr/bin/env python3

import apsw.shell

def main():
    apsw.shell.main()

if __name__ == '__main__':
    main()
