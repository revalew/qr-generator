from sympy.plotting.backends.matplotlibbackend.matplotlib import (
    MatplotlibBackend, _matplotlib_list
)

__all__ = ["MatplotlibBackend", "_matplotlib_list"]
