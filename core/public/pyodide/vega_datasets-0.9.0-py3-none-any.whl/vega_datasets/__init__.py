from vega_datasets.core import DataLoader, LocalDataLoader

data = DataLoader()
local_data = LocalDataLoader()
__version__ = "0.9.0"
