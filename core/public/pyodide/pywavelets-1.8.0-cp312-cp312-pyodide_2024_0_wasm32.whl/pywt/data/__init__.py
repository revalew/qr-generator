from ._readers import aero, ascent, camera, ecg, nino
from ._wavelab_signals import demo_signal
