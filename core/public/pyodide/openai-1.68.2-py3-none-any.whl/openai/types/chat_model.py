# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.


from .shared import chat_model

__all__ = ["ChatModel"]

ChatModel = chat_model.ChatModel
