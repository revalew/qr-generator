"""
The `river.tree.nodes` module includes learning and split node
implementations for the hoeffding trees.
"""
