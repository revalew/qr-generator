# Contributing to PyScript

Please see our guide to contributing to PyScript
[in our documentation](https://docs.pyscript.net/latest/contributing/).
