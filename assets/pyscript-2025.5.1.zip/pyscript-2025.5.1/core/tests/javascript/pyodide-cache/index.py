import numpy as np
import matplotlib as mpl

# just do something with the packages
print(len(dir(np)))
print(len(dir(mpl)))
