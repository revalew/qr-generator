def runtime_version():
    import sys

    return sys.version


__export__ = ["runtime_version"]
