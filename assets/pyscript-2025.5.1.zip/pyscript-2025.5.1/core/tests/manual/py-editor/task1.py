from pyscript import window

window.console.log("OK")

a = 1
