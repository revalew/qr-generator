from pyscript import sync

sync.get_class = lambda: "ok"
