print(input("What food would you like me to get from the shop? "))
