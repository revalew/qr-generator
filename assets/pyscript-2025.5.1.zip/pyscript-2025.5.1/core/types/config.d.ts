export function configDetails(config: string, type: string | null): {
    json: boolean;
    toml: boolean;
    text: string;
};
export const configs: Map<any, any>;
export function relative_url(url: any, base?: string): string;
