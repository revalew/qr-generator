declare function _default(main: any, wrap: any, element: any, hook: any): Promise<void>;
export default _default;
