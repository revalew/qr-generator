export const stdlib: string;
export const optional: string;
