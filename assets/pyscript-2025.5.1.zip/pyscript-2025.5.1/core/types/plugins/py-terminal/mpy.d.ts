declare function _default(element: any): Promise<void>;
export default _default;
