declare var i: any;
declare var o: any;
declare var s: {};
export { i as FitAddon, o as __esModule, s as default };
